<?php
/**
 * Plugin Name: LionThemes Helper
 * Plugin URI: http://lion-themes.com/
 * Description: The helper plugin for LionThemes themes.
 * Version: 1.0.0
 * Author: LionThemes
 * Author URI: http://lion-themes.com/
 * Text Domain: lionthemes
 * License: GPL/GNU.
 *  Copyright 2016  LionThemes  (email : support@lion-themes.com)
*/

//Less compiler
function compileLess($input, $output, $params){
    // input and output location
	$inputFile = get_stylesheet_directory().'/less/'.$input;
	$outputFile = get_stylesheet_directory().'/css/'.$output;
	if(!file_exists($inputFile)) return;
	// include Less Lib
	if(file_exists( plugin_dir_path( __FILE__ ) . 'less/Less.php' )){
		require_once( plugin_dir_path( __FILE__ ) . 'less/Less.php' );
		$options = array( 'compress' => true );
		try{
			$parser = new Less_Parser( $options );
			$parser->ModifyVars( $params );
			$parser->parseFile( $inputFile );
			$css = $parser->getCss();
			file_put_contents($outputFile, $css);
		}catch(Exception $e){
			$error_message = $e->getMessage();
			echo $error_message;
		}
	}
}
$shortcodes = array(
	'brands.php',
	'blogposts.php',
	'products.php',
	'productscategory.php',
	'testimonials.php',
);
//Shortcodes for Visual Composer
foreach($shortcodes as $shortcode){
	if ( file_exists( plugin_dir_path( __FILE__ ). 'shortcodes/' . $shortcode ) ) {
		require_once plugin_dir_path( __FILE__ ) . 'shortcodes/' . $shortcode;
	}
}
?>
