<?php
function voisen_testimonials_shortcode( $atts ) {
	extract( shortcode_atts( array(
		'title'=>'',
		'el_class' => '',
		'number' => 10,
		'style'=>'carousel',
		'columns' => 1,
		'desksmall' => '4',
		'tablet_count' => '3',
		'tabletsmall' => '2',
		'mobile_count' => '1',
		'margin' => '30'
	), $atts, 'specifyproducts' ) );

	$_id = voisen_make_id();
	$args = array(
		'post_type' => 'testimonial',
		'posts_per_page' => $number,
		'post_status' => 'publish'
	);

$query = new WP_Query($args);
?>
<?php if($query->have_posts()){ ob_start(); ?>
	<div class="testimonials <?php echo esc_attr($el_class); ?>">
		<?php if($title){ ?><h3 class="vc_widget_title vc_testimonial_title"><span><?php echo esc_html($title); ?></span></h3><?php } ?>
		<div <?php echo ($style == 'carousel') ? 'data-dots="true" data-desksmall="'. esc_attr($desksmall) .'" data-tabletsmall="'. esc_attr($tabletsmall) .'" data-mobile="'. esc_attr($mobile_count) .'" data-tablet="'. esc_attr($tablet_count) .'" data-margin="'. esc_attr($margin) .'" data-nav="false" data-owl="slide" data-item-slide="'. esc_attr($columns) .'" data-ow-rtl="false"':'' ?> id="testimonial-<?php echo esc_attr($_id); ?>" class="testimonials-list<?php echo ($style == 'carousel') ? ' owl-carousel owl-theme':'' ?>">
			<?php $i=0; while($query->have_posts()): $query->the_post(); $i++; ?>
				<!-- Wrapper for slides -->
				<div class="quote">
					<blockquote class="testimonials-text">
						<?php the_content(); ?>
					</blockquote>
                    <div class="image">
                        <?php the_post_thumbnail( 'thumbnail' ); ?>
                    </div>
					<cite class="author">
						<span><?php the_title(); ?></span>
					</cite>
				</div>
			<?php endwhile; ?>
		</div>
	</div>
<?php 
	$content = ob_get_contents();
	ob_end_clean();
	wp_reset_postdata();
	return $content;
	}
}
add_shortcode( 'testimonials', 'voisen_testimonials_shortcode' );
?>